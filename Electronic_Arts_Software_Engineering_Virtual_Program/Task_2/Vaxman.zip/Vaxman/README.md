## Vax-Man

<hr>

<br>

Vax-Man is a re-implementation of Pacman, created in C++, using the Qt library.

<br>

Forked from: [https://github.com/dzui42unit/pacman](https://github.com/dzui42unit/pacman)

GitHub Link: https://github.com/melwyncarlo/Vax-Man-in-CPP

YouTube Link: [https://youtu.be/HrdsdiylnBQ](https://youtu.be/HrdsdiylnBQ)

<br>

Edited by: **Melwyn Francis Carlo (2021)**

